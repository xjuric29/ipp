from interpret_lib import core

if __name__ == '__main__':
    interpret = core.Interpret()
    interpret.start()

class ExitCodes:
    badParameter = 10
    inFileError = 11
    outFileError = 12
    xmlError = 31
    syntaxError = 32
    semanticError = 52
    runErrorBadType = 53
    runErrorMissingVar = 54
    runErrorMissingFrame = 55
    runErrorMissingValue = 56
    runErrorZeroDivision = 57
    runErrorBadStringOperation = 58
    internalError = 99
